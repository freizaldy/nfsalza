import Vue from 'vue';
import VueTyped from 'vue-typed-js';
Vue.use(VueTyped);
