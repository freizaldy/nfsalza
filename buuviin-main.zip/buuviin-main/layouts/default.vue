<template>
  <v-app>
    <audio src="~/assets/music.mp3" autoplay controls loop style="opacity:0" />
      <nuxt />
  </v-app>
</template>

<script>
export default {};
</script>
