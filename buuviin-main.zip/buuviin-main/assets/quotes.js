// prettier-ignore
export default [
    { author: "Freizaldy.", quotes: "Whatever happens, keep breathing" },
    { author: "Farrasreizaldy", quotes: "Hey Salza! I love you." },
    { author: "Freizaldy", quotes: "I love you, Salza." },
    { author: "Freizaldy", quotes: "I may not with you everyday, but I love you everyday. Salza Nur Fatimah" },
    { author: "Freizaldy", quotes: "I love you, Salza Nur Fatimah" },
    { author: "Freizaldy", quotes: "I'm sorry for loving you." },
];
