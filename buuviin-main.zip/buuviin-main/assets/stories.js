export default [
  "Hi, Salza Nur Fatimah!",
  "Klik next ya!",
  "Udah itu aja",
  "Aku sayang kamu!"
];
