export default {
  nicknames: ["Salza", "Sasa", "Caaaa", "Sa"],
  greetings: {
    evening: "Good Evening",
    afternoon: "Good Afternoon",
    day: "Good Day",
    morning: "Good Morning",
    night: "Good Night"
  }
};
